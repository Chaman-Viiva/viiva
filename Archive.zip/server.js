#!/usr/bin/env node
/**
 * Start file for cPanel Node.js app.
 * Run after: npm install && npm run build
 * In cPanel set Application startup file to: server.js
 */
const path = require('path');
const { spawn } = require('child_process');

process.chdir(__dirname);

const nextBin = path.join(__dirname, 'node_modules', 'next', 'dist', 'bin', 'next');
const child = spawn(process.execPath, [nextBin, 'start'], {
  stdio: 'inherit',
  cwd: __dirname,
  env: { ...process.env, NODE_ENV: 'production' },
});

child.on('exit', (code) => process.exit(code != null ? code : 0));
